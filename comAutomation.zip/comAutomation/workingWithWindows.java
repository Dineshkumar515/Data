package comAutomation;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class workingWithWindows {

	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://leafground.com/window.xhtml");
		
		String handle= driver.getWindowHandle();
		
		WebElement firstButton=driver.findElement(By.id("j_idt88:new"));
		firstButton.click();
	Set<String>handles=	driver.getWindowHandles();
	for (String newWindows : handles) {
		driver.switchTo().window(newWindows);
	}
		WebElement tickBox=driver.findElement(By.xpath("//*[@id=\"j_idt107\"]/div[2]"));
		tickBox.click();
		driver.close();
		driver.switchTo().window(handle);
		
		WebElement multiWindow=driver.findElement(By.id("j_idt88:j_idt91"));
		multiWindow.click();
		int noOfWindows=driver.getWindowHandles().size();
		System.out.println("No of windows:"+noOfWindows);
		driver.switchTo().defaultContent();
		
		
		WebElement closeWindows=driver.findElement(By.id("j_idt88:j_idt93"));
		closeWindows.click();
		Set<String>newwindowHandle= driver.getWindowHandles();
		for (String allWindows : newwindowHandle) {
			if(!allWindows.equals(handle)) {
				driver.switchTo().window(allWindows);
				driver.close();
				}
			}
		WebElement delayWindow=driver.findElement(By.id("j_idt88:j_idt95"));
		Thread.sleep(3000);
		delayWindow.click();
			
		}
		
}
	

