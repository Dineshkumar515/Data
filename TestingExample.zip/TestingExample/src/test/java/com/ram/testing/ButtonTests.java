package com.ram.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

public class ButtonTests {
	
	static EdgeDriver driver = new EdgeDriver();

	static void guru() throws InterruptedException {
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");

		WebElement button = driver.findElement(By.xpath("//*[@id=\"authentication\"]/span"));
		
		//"//*[@id=\"authentication\"]/button"
		
		//*[@id="authentication"]/span
		//*[@id="authentication"]/span
		// Explicit wait for the button to be present
		// WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//		WebElement button = wait
//				.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"authentication\"]/button")));

		// Perform a double-click action
//		Actions action = new Actions(driver);
//		action.doubleClick(button).perform();

		new Actions(driver).doubleClick(button).perform();
		Thread.sleep(3000);

		// Handle the alert
		driver.switchTo().alert().accept();

		Thread.sleep(3000);

		// right click button
		// contextClick() - it is used for right click
		WebElement rightClick = driver.findElement(By.xpath("//span[text()='right click me']"));
		Actions actions = new Actions(driver);
		actions.contextClick(rightClick).perform();

		driver.findElement(By.cssSelector(".context-menu-item.context-menu-icon.context-menu-icon-edit")).click();

//		wait.until(ExpectedConditions
//				.elementToBeClickable(By
//				.cssSelector(".context-menu-item.context-menu-icon.context-menu-icon-edit")))
//				.click();

		Thread.sleep(3000);
		// Handle the alert that appears after selecting "Edit"
		driver.switchTo().alert().accept();
	}

	static void demoqa() throws InterruptedException {
		driver.get("https://demoqa.com/buttons");
		Actions action = new Actions(driver);

		WebElement doubleClick = driver.findElement(By.xpath("//*[@id=\"doubleClickBtn\"]"));
		action.doubleClick(doubleClick).perform();

		Thread.sleep(3000);

		WebElement rightClick = driver.findElement(By.id("rightClickBtn"));
		action.contextClick(rightClick).perform();

		Thread.sleep(3000);

		driver.findElement(By.xpath("//button[text()='Click Me']")).click();
	}

	public static void main(String[] args) throws InterruptedException {
		try {
			// guru();
			demoqa();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Thread.sleep(3000);
			driver.quit();
		}
	}
}
