package comAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class dropDownExample {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://www.leafground.com/select.xhtml");
		
		WebElement dropDownone= driver.findElement(By.xpath("//*[@id=\"j_idt87\"]/div/div[1]/div[1]/div/div/select"));
		
		Select select=new Select(dropDownone);
		select.selectByIndex(3);
		//Thread.sleep(3000);
		
		select.selectByVisibleText("Playwright");
		//WebElement dropDownTwo=driver.findElement(By.id("j_idt87:lang_label"));
		
		List<WebElement> listOfOptions= select.getOptions();
		int size=listOfOptions.size();
		System.out.println("the size is"+size);
		

		dropDownone.sendKeys("selenium");  			// The sendkeys is also used in dropdown method also 
		
		WebElement multipleSelectBox=driver.findElement(By.id("j_idt87:auto-complete_input"));
		 Select multipleSelect=new Select(multipleSelectBox);
		 multipleSelect.selectByVisibleText("Appium");
		 multipleSelect.selectByVisibleText("Selenium WebDriver");
		 multipleSelect.selectByVisibleText("ReactJs");
		 multipleSelect.selectByVisibleText("PostMan");
		 multipleSelect.selectByVisibleText("AWS");
		 
		 
		 
		 
		
		
		
		
		
		

	}

}
