package com.ram.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleLogin {
	public static void main(String[] args) {
		
		ChromeDriver driver = new ChromeDriver();
		
		try {
			
			driver.get("https:\\www.google.com");
			
			// Reject All button
			// driver.findElement(By.xpath("//*[@id=\"W0wltc\"]/div")).click();

			driver.findElement(By.id("APjFqb")).sendKeys("Account sign-in" + Keys.ENTER);
			
			driver.findElement(By.linkText("Sign in")).click();

			driver.findElement(By.id("identifierId")).sendKeys("ramlaproughuse@gmail.com" + Keys.ENTER);
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
//		finally {
//			driver.quit();
//		}
	}
}
