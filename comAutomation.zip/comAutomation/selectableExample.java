package comAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class selectableExample {

	public static void main(String[] args) {
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://only-testing-blog.blogspot.com/2014/09/selectable.html");
		
	List<	WebElement >selet= driver.findElements(By.xpath("//*[@id=\'selectable\']/li"));
		int size=selet.size();
		System.out.println(size);
		Actions action=new Actions(driver);
		action.keyDown(Keys.CONTROL).click(selet.get(0)).click(selet.get(1)).click(selet.get(2)).build().perform();
		
		
		
	}

}
