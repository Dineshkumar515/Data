package com.ram.testing;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Headless {

	public static void main(String[] args) {

		// Headless means works without UI.
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--headless");

		ChromeDriver driver = new ChromeDriver(options);

		driver.get("https:\\www.youtube.com");
		System.out.println("The title of the page: " + driver.getTitle());
		System.out.println("The current URL of this page: " + driver.getCurrentUrl());

	}

}
