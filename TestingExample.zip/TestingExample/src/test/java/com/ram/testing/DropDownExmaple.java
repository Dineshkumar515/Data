package com.ram.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDownExmaple {
	static ChromeDriver driver = new ChromeDriver();

	static void demoQA() {
		driver.get("https://demoqa.com/select-menu");
		
		WebElement dropDown1 = driver.findElement(By.id("withOptGroup"));
		Select select = new Select(dropDown1);
		select.selectByIndex(1);
	}

	public static void main(String[] args) throws InterruptedException {
		try {
			demoQA();
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			Thread.sleep(3000);
			driver.quit();
		}

	}

}
