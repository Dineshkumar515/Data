package comAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class sortablesExample {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		driver.navigate().to("https://sortablejs.github.io/Sortable/");;
		
		List<WebElement> elements=driver.findElements(By.xpath("//*[@id=\'example1\']"));
		
		WebElement fromElement=elements.get(5);
		WebElement toElement=elements.get(2);
		
		Actions actions=new Actions(driver);
		
		actions.clickAndHold(fromElement);
		actions.moveToElement(toElement);
		actions.release(toElement);
		actions.build().perform();
		
		

	}

}
