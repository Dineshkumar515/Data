package comAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class radioButton {

	public static void main(String[] args) {
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://leafground.com/radio.xhtml");
		WebElement favBox= driver.findElement(By.xpath("//*[@id=\"j_idt87:console1\"]/tbody/tr/td[1]/div/div[2]/span"));
		favBox.click();
		
		WebElement checkBox=driver.findElement(By.xpath("//*[@id=\"j_idt87:console2\"]/tbody/tr/td[3]/div/div[2]"));
		 Boolean isClicked =checkBox.isSelected();
		 System.out.println(isClicked);
		
		WebElement unCheckBox= driver.findElement(By.xpath("//*[@id=\"j_idt87:console2\"]/tbody/tr/td[2]/div/div[2]/span"));
		 Boolean notClicked=unCheckBox.isSelected();
		 System.out.println(notClicked);
		
		WebElement ageBox=driver.findElement(By.xpath("//*[@id=\"j_idt87:age\"]/div/div[2]/div/div[2]/span"));
		 ageBox.click();
		 }

}
