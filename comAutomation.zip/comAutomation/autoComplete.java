package comAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class autoComplete {

	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.google.co.in/");
		
		WebElement auto=driver.findElement(By.id("APjFqb"));
		auto.sendKeys("s");
		Thread.sleep(4000);
		
	List<WebElement> optionsList=driver.findElements(By.xpath("//*[@id=\'APjFqb\']/li"));
		for (WebElement webElement : optionsList) {
			if(webElement.getText().equals("snapinsta")) {
				webElement.click();
				System.out.println("The selected option is "+webElement.getText());
				break;
				
			}
		}

	}

}
