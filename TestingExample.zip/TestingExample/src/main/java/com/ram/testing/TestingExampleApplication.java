package com.ram.testing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestingExampleApplication.class, args);
	}

}
