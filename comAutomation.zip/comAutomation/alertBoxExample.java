package comAutomation;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class alertBoxExample {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.leafground.com/alert.xhtml");
		
		WebElement confirmBox= driver.findElement(By.xpath("//*[@id=\"j_idt88:j_idt93\"]/span[2]"));
		confirmBox.click();
		Alert confirmAlert=driver.switchTo().alert();
		confirmAlert.dismiss();
		Thread.sleep(3000);
		WebElement entryBox= driver.findElement(By.xpath("//*[@id=\"j_idt88:j_idt104\"]/span[2]"));
		entryBox.click();
		Alert entryAlert=driver.switchTo().alert();
		Thread.sleep(3000);
		entryAlert.sendKeys("TEsting");
		entryAlert.accept();
		Thread.sleep(2000);
		WebElement simpleBox= driver.findElement(By.xpath("//*[@id=\"j_idt88:j_idt91\"]/span[2]"));
		simpleBox.click();
		


	}

}
