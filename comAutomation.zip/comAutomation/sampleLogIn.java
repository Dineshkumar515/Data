package comAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class sampleLogIn {
	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
		WebElement loginID=driver.findElement(By.id("user-name"));
		loginID.sendKeys("standard_user");
		Thread.sleep(3000);
		WebElement passK=driver.findElement(By.id("password"));
		passK.sendKeys("secret_sauce");
		Thread.sleep(3000);
		WebElement button=driver.findElement(By.id("login-button"));
		button.click();
		
		
	}

}
