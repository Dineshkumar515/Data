package comAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class demoPocOne {

	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
		Thread.sleep(1000);
		driver.manage().window().maximize();
		driver.findElement(By.id("user-name")).sendKeys("visual_user");
		Thread.sleep(1000);
		driver.findElement(By.id("password")).sendKeys("OpenSource");
		Thread.sleep(1000);
		driver.findElement(By.id("login-button")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/div[3]/h3")).getText());
		//driver.findElement(By.xpath("//div/input[3]")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("password")).clear();
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("secret_sauce");
		Thread.sleep(1000);
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("add-to-cart-sauce-labs-fleece-jacket")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/span")).click();
		Thread.sleep(1500);
		driver.findElement(By.id("remove-sauce-labs-bike-light")).click();
		Thread.sleep(1500);
		driver.findElement(By.id("checkout")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("first-name")).sendKeys("Sridharan");
		Thread.sleep(1000);
		driver.findElement(By.id("last-name")).sendKeys("V R");
		Thread.sleep(1000);
		driver.findElement(By.id("postal-code")).sendKeys("600130");
		Thread.sleep(1500);
		driver.findElement(By.id("continue")).click();
		Thread.sleep(1500);
		driver.findElement(By.id("finish")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("back-to-products")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("react-burger-menu-btn")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("logout_sidebar_link")).click();
		
		
		
		
		
		
		
		
		
		
		

	}

}
