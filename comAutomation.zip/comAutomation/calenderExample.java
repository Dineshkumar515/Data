package comAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class calenderExample {

	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver= new ChromeDriver();
		driver.navigate().to("https://www.globalsqa.com/demo-site/datepicker/");
		
		WebElement datePicker= driver.findElement(By.className("hasDatepicker"));
		datePicker.click();
		
		WebElement nextKey= driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div/a[2]"));
		nextKey.click();
		Thread.sleep(2000);
		WebElement nextKey2= driver.findElement(By.xpath("//*[@id=\\\"ui-datepicker-div\\\"]/div/a[2]']"));
		nextKey2.click();
		Thread.sleep(2000);
		WebElement nextKey3= driver.findElement(By.xpath("//*[@id=\\\"ui-datepicker-div\\\"]/div/a[2]"));
		nextKey3.click();
		Thread.sleep(2000);
		
		WebElement dateClick= driver.findElement(By.xpath("//a[contains(text(),22)]"));
		dateClick.click();
		

	}

}
