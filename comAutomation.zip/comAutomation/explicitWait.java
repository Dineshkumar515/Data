package comAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class explicitWait {
	public static void main(String[] args) 
	{
		implicitWait();
	}
	public static void implicitWait(){
		 
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://phptravels.net/login");
		
		driver.findElement(By.id("email")).sendKeys("user@phptravels.com");
		driver.findElement(By.id("password")).sendKeys("demouser");
		driver.findElement(By.id("submitBTN")).click();
		driver.findElement(By.xpath("//*[@id=\"fadein\"]/main/div/div/div/div[2]/ul/li[3]/a")).click();
		driver.findElement(By.id("Address")).sendKeys("Chennai");
		//driver.findElement(By.xpath("//*[@id=\"profile\"]/div/div[6]/button")).click();
		WebDriverWait wait=new WebDriverWait(driver, null);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"profile\"]/div/div[6]/button"))).click();
		driver.quit();
	}
	}
