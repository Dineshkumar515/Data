package comAutomation;

import java.awt.AWTException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class cognizantExample {

	public static void main(String[] args) throws AWTException {
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://www.cognizant.com/in/en");
		driver.manage().window().maximize();
		WebElement carrerClick= driver.findElement(By.xpath("//*[@id=\"container-2a25a4860e\"]/div[1]/header/div[1]/div/div[2]/ul/li[1]/a"));
		carrerClick.click();
		WebElement cookie=driver.findElement(By.id("js-cookie-accept"));
		cookie.click();
		WebElement searchJob= driver.findElement(By.name("keyword"));
		searchJob.sendKeys("Java"+Keys.ENTER);
	
		
		
		


		
		
		
	}

}
//https://www.youtube.com/wbatch?v=lx-B1PVTRmQ