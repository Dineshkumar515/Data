package comAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class buttonExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChromeDriver driver = new ChromeDriver();
		//1. position of button
		driver.get("https://www.leafground.com/button.xhtml");
		WebElement getPositionButton= driver.findElement(By.id("j_idt88:j_idt94"));
		org.openqa.selenium.Point xypoint=getPositionButton.getLocation();
		int xValue=xypoint.getX();
		int yValue=xypoint.getY();
		System.out.println("X position "+xValue+" Y position"+yValue);
		
		//2. Color of the button
		WebElement getColour= driver.findElement(By.id("j_idt88:j_idt94"));
		String color= getColour.getCssValue("background");
		System.out.println("the colour of the button is "+color);
		
		// 3. size of button ( height and width)
		WebElement getSizeButton= driver.findElement(By.id("j_idt88:j_idt98"));
		int height= getSizeButton.getSize().getHeight();
		int width= getSizeButton.getSize().getWidth();
		System.out.println("Height is"+height+"width is "+width);
		
		//4. go to home page
		 driver.findElement(By.id("j_idt88:j_idt98")).click();
		
		
		
		
		
		
		
	}
	

}
