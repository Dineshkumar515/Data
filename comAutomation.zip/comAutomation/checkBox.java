package comAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class checkBox {

	public static void main(String[] args) {
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://leafground.com/checkbox.xhtml");
		WebElement basicBox=driver.findElement(By.xpath("//*[@id=\"j_idt87:j_idt89\"]/div[2]"));
		basicBox.click();
		
		WebElement disabledBox=driver.findElement(By.id("j_idt87:j_idt102"));
		Boolean isDisabled=disabledBox.isSelected();
		System.out.println(isDisabled);
			
		WebElement toggleBox=driver.findElement(By.xpath("//*[@id=\"j_idt87:j_idt100\"]/div[2]"));
		toggleBox.click();
		
		WebElement multipleBox=driver.findElement(By.xpath("//*[@id=\"j_idt87:multiple\"]/ul"));
		multipleBox.click();
		driver.findElement(By.xpath("//*[@id=\"j_idt87:multiple_panel\"]/div[2]/ul/li[1]/div/div[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"j_idt87:multiple_panel\"]/div[2]/ul/li[2]/div/div[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"j_idt87:multiple_panel\"]/div[2]/ul/li[3]/div/div[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"j_idt87:multiple_panel\"]/div[2]/ul/li[4]/div/div[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"j_idt87:multiple_panel\"]/div[1]/a")).click();
	}

}
