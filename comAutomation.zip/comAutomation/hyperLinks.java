package comAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class hyperLinks {

	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver= new ChromeDriver();
		driver.navigate().to("https://leafground.com/link.xhtml");
			
		WebElement homePageLink= driver.findElement(By.linkText("Go to Dashboard"));
		homePageLink.click();
		Thread.sleep(2000);
		driver.navigate().back();
		
		WebElement withoutClicking= driver.findElement(By.partialLinkText(" without clicking me."));
		String texts=	withoutClicking.getAccessibleName();
		System.out.println("The Link is navigated to the page:"+texts);
		
		WebElement brokenLink=driver.findElement(By.linkText("Broken?"));
		brokenLink.click();
		String title=	driver.getTitle();
		if(title.equals("404")) {
			System.out.println("The link is broken.");
			}
		driver.navigate().back();
		Thread.sleep(2000);
		
		WebElement homePageLink2= driver.findElement(By.linkText("Go to Dashboard"));
		homePageLink2.click();
		Thread.sleep(2000);
		driver.navigate().back();
		
		List<WebElement> totalLinks=driver.findElements(By.tagName("a"));
		int size=totalLinks.size();
		System.out.print("Total number of links is:"+size);
		

	}

}
