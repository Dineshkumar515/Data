package comAutomation;

import org.openqa.selenium.chrome.ChromeDriver;

public class getVsNavigate {
	public void getVSNavigate(){
	ChromeDriver driver=new ChromeDriver();
	driver.get("https://www.youtube.com/");
	driver.navigate().to("https://www.youtube.com/");
	driver.navigate().back();	
	driver.navigate().forward();
	driver.navigate().refresh();
	}
	
}
		//get will give wait till the elements appears on DOM || Navigate won't wait 
		//Navigate wil have history of the page so that we can move forward and backward
			