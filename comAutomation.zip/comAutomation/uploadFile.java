package comAutomation;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class uploadFile {

	public static void main(String[] args) throws AWTException  {
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://letcode.in/file");
		
		WebElement uploadKey=driver.findElement(By.xpath("/html/body/app-root/app-filemanagement/section[1]/div/div/div[1]/div/div[1]/div/div/label/span/span[2]"));
		uploadKey.click();
		String file="C:\\Users\\2117005\\OneDrive - Cognizant\\Documents\\SAMPLEBOPK.xls";
		StringSelection selection= new StringSelection(file);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
		
		Robot robort=new Robot();
		robort.keyPress(KeyEvent.VK_CONTROL);
		robort.keyPress(KeyEvent.VK_V);
		robort.keyRelease(KeyEvent.VK_V);
		robort.keyRelease(KeyEvent.VK_CONTROL);
		
		robort.keyPress(KeyEvent.VK_ENTER);
		robort.keyRelease(KeyEvent.VK_ENTER);
		
		
	}

}
