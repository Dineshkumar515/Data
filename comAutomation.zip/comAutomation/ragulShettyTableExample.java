package comAutomation;

import org.openqa.selenium.chrome.ChromeDriver;

public class ragulShettyTableExample {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://www.rahulshettyacademy.com/AutomationPractice/");
		

	}

}
