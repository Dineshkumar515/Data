package comAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class playingWithImages {

	public static void main(String[] args) {
		ChromeDriver driver= new ChromeDriver();
		// driver.get("https://jsonplaceholder.typicode.com/");
		// WebElement imageClick= driver.findElement(By.xpath("/html/body/div/section[2]/p[2]/a/img"));
		 //imageClick.click();

		driver.get("https://the-internet.herokuapp.com/broken_images");
		WebElement brokenImage=driver.findElement(By.xpath("//*[@id=\"content\"]/div/img[1]"));
		brokenImage.click();
		
		if(brokenImage.getAttribute("naturalWidth").equals("0")) {
			System.out.println("The image is broken");
			
		}else {
			System.out.println("The image is not broken");
		}
			
	}

}
