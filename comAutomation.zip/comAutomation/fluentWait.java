package comAutomation;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;

public class fluentWait {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}
//	
	public void fluentWaitExample(){
		 
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://phptravels.net/login");
		
		driver.findElement(By.id("email")).sendKeys("user@phptravels.com");
		driver.findElement(By.id("password")).sendKeys("demouser");
		driver.findElement(By.id("submitBTN")).click();
		driver.findElement(By.xpath("//*[@id=\"fadein\"]/main/div/div/div/div[2]/ul/li[3]/a")).click();
		driver.findElement(By.id("Address")).sendKeys("Chennai");
		
		Wait<WebDriver>wait =new FluentWait<WebDriver>(driver)
						.withTimeout(Duration.ofSeconds(30))
						.pollingEvery(Duration.ofSeconds(3))
						.ignoring(org.openqa.selenium.NoSuchElementException.class); //why ? NoSuchElemetException is in both JAVA and SELENIUM so we should call the function form selenium and not form java and also import the func from selenium package
	WebElement profile=	wait.until(new Function<WebDriver,WebElement>() {
				public WebElement apply(WebDriver driver) {
				// TODO Auto-generated method stub
				return driver.findElement(By.xpath("//*[@id=\"profile\"]/div/div[6]/button"));
				
			}
				
			
		});
				profile.click();
		
							
		
		}


}
