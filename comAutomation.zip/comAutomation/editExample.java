package comAutomation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class editExample {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://leafground.com/input.xhtml");
		WebElement nameBox=driver.findElement(By.name("j_idt88:name"));
		nameBox.sendKeys("Sridharan");
		
		WebElement appendBox=driver.findElement(By.xpath("//*[@id=\'j_idt88:j_idt91\']"));
		appendBox.sendKeys("hi");
		
		WebElement attributeBox=driver.findElement(By.name("j_idt88:j_idt97"));
		String va=attributeBox.getAttribute("value");
		System.out.println(va);
		
		WebElement clearBox=driver.findElement(By.name("j_idt88:j_idt95"));
		clearBox.clear();
		
		
		
		

	}

}
