package com.ram.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {

	static ChromeDriver driver = new ChromeDriver();

	public static void heroku() {

		driver.get("http://the-internet.herokuapp.com/basic_auth");

		String username = "admin";
		String password = "admin";

		String baseUrl = "http://" + username + ":" + password + "@the-internet.herokuapp.com/basic_auth";

		driver.get(baseUrl);

	}

	public static void guru() {
		driver.get("https://demo.guru99.com/test/login.html");
		driver.findElement(By.id("email")).sendKeys("test");
		driver.findElement(By.id("passwd")).sendKeys("test"+Keys.ENTER);
		// driver.findElement(By.id("SubmitLogin")).click();

	}

	public static void main(String[] args) {
		try {
		heroku();
			guru();
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		
		finally {
			driver.quit();
		}


	}
}
