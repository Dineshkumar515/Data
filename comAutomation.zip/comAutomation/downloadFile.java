package comAutomation;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class downloadFile {

	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://leafground.com/file.xhtml");
		
		WebElement button=driver.findElement(By.id("j_idt93:j_idt95"));
		button.click();
		Thread.sleep(3000);
		
		File fileLocator= new File("C:\\Users\\2117005\\Downloads");
	File[] totalFiles=	fileLocator.listFiles();
		for (File file : totalFiles) {
			file.getName().equals("Download");
			System.out.println("the file is downloaded");
			break;
			
		}
		

	}

}
