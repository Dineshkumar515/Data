package comAutomation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class implicitWaitExample {
	 @SuppressWarnings("deprecation")
	@Test
	public void implicitWait(){
		 
	ChromeDriver driver= new ChromeDriver();
	driver.get("https://phptravels.net/login");
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
	driver.findElement(By.id("email")).sendKeys("user@phptravels.com");
	driver.findElement(By.id("password")).sendKeys("demouser");
	driver.findElement(By.id("submitBTN")).click();
	driver.findElement(By.xpath("//*[@id=\"fadein\"]/main/div/div/div/div[2]/ul/li[3]/a")).click();
	driver.findElement(By.id("Address")).sendKeys("Chennai");
	driver.findElement(By.xpath("//*[@id=\"profile\"]/div/div[6]/button")).click();
	
	
	}

}
//user@phptravels.com
//demouser