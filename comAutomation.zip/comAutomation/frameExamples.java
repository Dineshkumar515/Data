package comAutomation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class frameExamples {

	public static void main(String[] args) {
		ChromeDriver driver= new ChromeDriver();		
		driver.get("https://leafground.com/frame.xhtml;jsessionid=node01wyxoggvr6h9akynudopqfxbu671183.node0");
		driver.switchTo().frame(0);
		
		WebElement boxOne=driver.findElement(By.id("Click"));
		boxOne.click();
		String value=boxOne.getText();
		System.out.println(value);
		
		
		
		driver.switchTo().defaultContent();
		List<WebElement> totalFrame=	driver.findElements(By.tagName("iframe"));
		int size=totalFrame.size();
		System.out.println(size);
		
		driver.switchTo().defaultContent();
		driver.switchTo().frame(2);
		driver.switchTo().frame("frame2");
		WebElement boxTwo= driver.findElement(By.xpath("//body/button"));
		boxTwo.click();
	
	}
	
}
