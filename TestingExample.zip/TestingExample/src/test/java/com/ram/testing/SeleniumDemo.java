package com.ram.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumDemo {

	public static void main(String[] args) {

		// Initializing the driver here because of finally block
		ChromeDriver driver = new ChromeDriver();
		try {
		// SetProperty("webDriver.chrome.driver", "Driver location");

		driver.get("https:\\www.google.com");

		// enter the search term and
		// click the enter button using KEYS method
		driver.findElement(By.id("APjFqb")).sendKeys("youtube" + Keys.ENTER);

		// If you are using Link Text
		// you need to give the text exactly what on the website.
		// driver.findElement(By.linkText("youtube.com")).click();

		// If you are using partialLinkText
		// you can give the partial text on the website.
		driver.findElement(By.partialLinkText("YouTube")).click();

	} catch (Exception e) {
		e.printStackTrace();
	}

		finally
		{
			driver.quit();
		}
	}

}
