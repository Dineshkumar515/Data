package comAutomation;

import java.io.File;
import java.io.IOException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;

public class screenShot {
	
	public static void main(String [] args)  throws IOException{
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://onecognizant.cognizant.com/Home#.");
		
		TakesScreenshot screenshot=(TakesScreenshot)driver;
	 File sourceFile=	screenshot.getScreenshotAs(OutputType.FILE);
	 File destinationFile=new File("C:\\Users\\2117005\\Downloads");
	 org.openqa.selenium.io.FileHandler.copy(sourceFile, destinationFile);
	 
	 
		
		
	}

}
